package kr.or.nextit.team1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Team1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
